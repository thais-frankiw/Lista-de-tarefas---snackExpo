import {
  SafeAreaView,
  Platform,
  StatusBar,
  View,
  Text,
  TextInput,
  Button,
  TouchableOpacity,
  StyleSheet,
  ScrollView
} from 'react-native';
import { useState } from 'react';
import { FontAwesome } from '@expo/vector-icons';

export default function App() {
  const [tarefas, setTarefas] = useState([]);
  const [inputUser, setInputUser] = useState('');

  const handleAddTarefa = () => {
    if (inputUser.trim()) {
      setTarefas([...tarefas, inputUser.trim()]);
      setInputUser('');
    }
  };

  const handleDeletarTarefa = (index) => {
    const newTarefas = tarefas.filter((tarefa, idx) => idx !== index);
    setTarefas(newTarefas);
  };

  return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.titulo}>Lista de tarefas</Text>
        <Text> Nova tarefa</Text>
        <View style={styles.inputContainer}>
          <TextInput 
            placeholder='O que precisa ser feito?' 
            value={inputUser} 
            onChangeText={setInputUser} 
            style={styles.input} 
            placeholderTextColor='#808080'
          />
          <Button title='Adicionar tarefa' onPress={handleAddTarefa}/>
        </View>

        <ScrollView style={styles.tarefaContainer}>
          {tarefas.map((tarefa, index) => (
            <View key={index} style={styles.tarefaItem}>
              <Text style={styles.tarefaText}>{`${index + 1}. ${tarefa}`}</Text>
              <TouchableOpacity onPress={() => handleDeletarTarefa(index)} style={styles.deleteButton}>
                <FontAwesome name="trash" size={20} color='red'/>
              </TouchableOpacity>
            </View>
          ))}
        
        </ScrollView>    
      </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight: 0,
    paddingHorizontal: 20,
  },

  titulo:{
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    marginTop: 5,
    textAlign: 'center',
  },

  inputContainer:{
    flexDirection: 'column',
    height: 70,
  },

  input:{
    flex:1,
    borderWidth: 2,
    borderColor: 'black',
    padding: 5,
    borderRadius: 5,
    marginRight: 2,
    marginLeft: 2,
    marginBottom: 5,
    color:'#000',
  },

  tarefaContainer: {
    flex:1,
  },

  tarefaItem:{
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'left',
    borderWidth: 2,
    borderColor: 'black',
    padding: 5,
    borderRadius: 5,
    marginRight: 2,
    marginLeft: 2,
    marginBottom: 5,

  },

  tarefaText:{
    fontSize: 20,
  },

  deleteButton:{
    padding: 5,
    alignSelf: 'flex-end',
  },

});